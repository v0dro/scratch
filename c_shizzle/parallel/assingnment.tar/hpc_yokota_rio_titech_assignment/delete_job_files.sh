rm job.sh.e*
rm job.sh.o*
