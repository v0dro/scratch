#include <iostream>
#include <immintrin.h>
using namespace std;

int main()
{
  double a[4] = {1.0,2.0,3.0,4.0};
  double b[4] = {1.0,2.0,3.0,4.0};
  double c[4] = {0,0,0,0};

  // __asm__ volatile("vmovapd  %%ymm0, (%0) \n\t"
  //                  "vmovapd  %%ymm1, (%1) \n\t"
  //                  "vmovapd  %%ymm2, (%2) \n\t"
  //                  "vfmadd231pd %%ymm2, %%ymm0, %%ymm1 \n\t"
  //                  "vmovapd  (%2), %%ymm2"
  //                  :
  //                  : "rm" (a), "rm" (b), "rm" (c)
  //                  :);
  __asm__ volatile("vmovapd  (%0), %%ymm0 \n\t"
                   "vmovapd  (%1), %%ymm1 \n\t"
                   "vmovapd  (%2), %%ymm2 \n\t"
                   "vfmadd231pd %%ymm0, %%ymm1, %%ymm2 \n\t"
                   "vmovapd  %%ymm2, (%2)"
                   :
                   : "rm" (a), "rm" (b), "rm" (c)
                   :);
  for (int i = 0; i < 4; i++)
    cout << c[i] << endl;
  return 0;
}
